const { sendMailToSos } = require("./email_Sender.js");
const mongoose = require("mongoose");
const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const port = 8080;

const mongoURI = "mongodb://localhost:27017/PetHelpDb"; // Replace with your actual MongoDB URI

// Connect to MongoDB
mongoose
  .connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("Connected to MongoDB database.");
    app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
  })
  .catch((err) => {
    console.error("Error connecting to MongoDB:", err);
    process.exit(1); // Exit the process if MongoDB connection fails
  });
  

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// app.listen(port, () => {
//   console.log(`Server is running on port ${port}`);
// });
const sosSchema = new mongoose.Schema({
  name: String,
  email: String,
  address1: String,
  address2: String,
  contact_no: String,
  role: String,
  user_recommend: String,
  comment: String,
  timestamp: { type: Date, default: Date.now },
});
const SOS = mongoose.model("SOS", sosSchema);

app.post("/sos", async (req, res) => {
  let {
    name,
    email,
    address1,
    address2,
    contact_no,
    role,
    user_recommend,
    comment,
  } = req.body;

  let template = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <style>
    /* Reset styles */
    body, h1, h2, h3, h4, p, ul, ol, li, table, tr, th, td {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }

    /* Container styles */
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      background-color: #f9f9f9;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    /* Header styles */
    h2 {
      font-size: 24px;
      margin-bottom: 20px;
    }

    /* Table styles */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #f2f2f2;
      font-weight: bold;
      text-align: left;
    }

    /* Table data styles */
    td {
      vertical-align: top;
    }

    /* Footer styles */
    footer {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
      color: #777;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Email Response</h2>
    <table>
      <tr>
        <th>Field</th>
        <th>Value</th>
      </tr>
      <tr>
        <td>Name</td>
        <td>${name}</td>
      </tr>
      <tr>
        <td>Email</td>
        <td>${email}</td>
      </tr>
      <tr>
        <td>Address 1</td>
        <td>${address1}</td>
      </tr>
      <tr>
        <td>Address 2</td>
        <td>${address2}</td>
      </tr>
      <tr>
        <td>Contact No</td>
        <td>${contact_no}</td>
      </tr>
      <tr>
        <td>Role</td>
        <td>${role}</td>
      </tr>
      <tr>
        <td>User Recommend</td>
        <td>${user_recommend}</td>
      </tr>
      <tr>
        <td>Comment</td>
        <td>${comment}</td>
      </tr>
    </table>
    <footer>
      This is an automated email. Please do not reply.
    </footer>
  </div>
</body>
</html>
`;

  const sosRequest = new SOS({
    name,
    email,
    address1,
    address2,
    contact_no,
    role,
    user_recommend,
    comment,
  });
  await sosRequest.save();
  console.log("SOS Request saved successfully.");

  // Send email
  try {
    await sendGmail(
      email,
      "SOS Request Received",
      "We Received Your SOS Request.",
      template
    );
    console.log("Email sent successfully.");
  } catch (error) {
    console.error("Error sending email:", error);
    // Handle email sending error if needed
  }

  // Send response with alert message
  const alert = `
    <script>
      alert("POST request accepted, welcome ${name}!");
    </script>
  `;
  res.send(alert);
});

app.post("/volunteer", async (req, res) => {
  let { name, email, address, city, state, country, number } = req.body;

  let template = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>We Received Your Request For Become Volunteer</title>
  <style>
    /* Reset styles */
    body, h1, h2, h3, h4, p, ul, ol, li, table, tr, th, td {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }

    /* Container styles */
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      background-color: #f9f9f9;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    /* Header styles */
    h2 {
      font-size: 24px;
      margin-bottom: 20px;
    }

    /* Table styles */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #f2f2f2;
      font-weight: bold;
      text-align: left;
    }

    /* Table data styles */
    td {
      vertical-align: top;
    }

    /* Footer styles */
    footer {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
      color: #777;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>We Received Your Request For Become Volunteer</h2>
    <table>
      <tr>
        <th>Field</th>
        <th>Value</th>
      </tr>
      <tr>
        <td>Name</td>
        <td>${name}</td>
      </tr>
      <tr>
        <td>Email</td>
        <td>${email}</td>
      </tr>
      <tr>
        <td>Address </td>
        <td>${address}</td>
      </tr>
      <tr>
        <td>city</td>
        <td>${city}</td>
      </tr>
      <tr>
        <td>Contact No</td>
        <td>${number}</td>
      </tr>
      
    </table>
   
    <footer>
    We will review your profile and get back to you when we need volunteer.<br>
    This is an automated email. Please do not reply.
    </footer>
  </div>
</body>
</html>
`;

  // Send email
  try {
    await sendGmail(
      email,
      "Volunteer Request Received",
      "We Received Your Request For Become Volunteer.",
      template
    );
    console.log("Email sent successfully.");
  } catch (error) {
    console.error("Error sending email:", error);
    // Handle email sending error if needed
  }

  // Send response with alert message
  const alert = `
    <script>
      alert("We Received Your Request For Become Volunteer, ${name}!");
    </script>
  `;
  res.send(alert);
});
app.post("/donatePet", async (req, res) => {
  let {
    name,
    email,
    address,
    city,
    state,
    country,
    number,
    pet_type,
    pet_name,
    pet_color,
    file_upload,
    pet_breed,
  } = req.body;

  let template = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>We Received Your Request For Become Volunteer</title>
  <style>
    /* Reset styles */
    body, h1, h2, h3, h4, p, ul, ol, li, table, tr, th, td {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }

    /* Container styles */
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      background-color: #f9f9f9;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    /* Header styles */
    h2 {
      font-size: 24px;
      margin-bottom: 20px;
    }

    /* Table styles */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #f2f2f2;
      font-weight: bold;
      text-align: left;
    }

    /* Table data styles */
    td {
      vertical-align: top;
    }

    /* Footer styles */
    footer {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
      color: #777;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>We Received Your Request For Become Volunteer</h2>
    <table>
      <tr>
        <th>Field</th>
        <th>Value</th>
      </tr>
      <tr>
        <td>Name</td>
        <td>${name}</td>
      </tr>
      <tr>
        <td>Email</td>
        <td>${email}</td>
      </tr>
      <tr>
        <td>Contact No</td>
        <td>${number}</td>
      </tr>
      </tr>
      <tr>
        <td>Pet Name</td>
        <td>${pet_name}</td>
      </tr>
      <tr>
        <td>Pet Type</td>
        <td>${pet_type}</td>
      </tr>
      <tr>
        <td>Pet Color</td>
        <td>${pet_color}</td>
      </tr>
      <tr>
        <td>Pet Breed</td>
        <td>${pet_breed}</td>
      </tr>
      
    </table>
   
    <footer>
    We received your request and get back to you as soon as possible.<br>
    This is an automated email. Please do not reply.
    </footer>
  </div>
</body>
</html>
`;

  // Send email
  try {
    await sendGmail(
      email,
      "Donation Request Received",
      "We received your request and get back to you as soon as possible.",
      template
    );
    console.log("Email sent successfully.");
  } catch (error) {
    console.error("Error sending email:", error);
    // Handle email sending error if needed
  }

  // Send response with alert message
  const alert = `
    <script>
      alert("We Received Your Request For Become Volunteer, ${name}!");
    </script>
  `;
  res.send(alert);
});
app.post("/contact_us", async (req, res) => {
  let { contact_message, contact_name, contact_email } = req.body;

  let template = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
  <style>
    /* Reset styles */
    body, h1, h2, h3, h4, p, ul, ol, li, table, tr, th, td {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }

    /* Container styles */
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      background-color: #f9f9f9;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    /* Header styles */
    h2 {
      font-size: 24px;
      margin-bottom: 20px;
    }

    /* Table styles */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #f2f2f2;
      font-weight: bold;
      text-align: left;
    }

    /* Table data styles */
    td {
      vertical-align: top;
    }

    /* Footer styles */
    footer {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
      color: #777;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>We Received Your Issue</h2>
    <table>
      <tr>
        <th>Field</th>
        <th>Value</th>
      </tr>
      <tr>
        <td>Name</td>
        <td>${contact_name}</td>
      </tr>
      <tr>
        <td>Email</td>
        <td>${contact_email}</td>
      </tr>
      <tr>
        <td>Message</td>
        <td>${contact_message}</td>
      </tr>
    </table>
    <footer>
    We received your issues and try to fix it as soon as possible.<br>
    This is an automated email. Please do not reply.
    </footer>
  </div>
</body>
</html>
`;

  // Send email
  try {
    await sendGmail(
      contact_email,
      "Complain Received",
      "We received your issues and try to fix it as soon as possible.",
      template
    );
    console.log("Email sent successfully.");
  } catch (error) {
    console.error("Error sending email:", error);
    // Handle email sending error if needed
  }

  // Send response with alert message
  const alert = `
    <script>
      alert("We Received Your Issue, ${contact_name}!");
    </script>
  `;
  res.send(alert);
});
app.post("/donate_money", async (req, res) => {
  let { name, email, address, city, state, country, number } = req.body;

  let template = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
  <style>
    /* Reset styles */
    body, h1, h2, h3, h4, p, ul, ol, li, table, tr, th, td {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }

    /* Container styles */
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      background-color: #f9f9f9;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    /* Header styles */
    h2 {
      font-size: 24px;
      margin-bottom: 20px;
    }

    /* Table styles */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #f2f2f2;
      font-weight: bold;
      text-align: left;
    }

    /* Table data styles */
    td {
      vertical-align: top;
    }

    /* Footer styles */
    footer {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
      color: #777;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Thank you For Donation</h2>
    <table>
      <tr>
        <th>Field</th>
        <th>Value</th>
      </tr>
      <tr>
        <td>Name</td>
        <td>${name}</td>
      </tr>
      <tr>
        <td>Email</td>
        <td>${email}</td>
      </tr>
      <tr>
        <td>Number</td>
        <td>${number}</td>
      </tr>
      <tr>
        <td>Address</td>
        <td>${address}</td>
      </tr>
      <tr>
        <td>City</td>
        <td>${city}</td>
      </tr>
      <tr>
        <td>State</td>
        <td>${state}</td>
      </tr>
      <tr>
        <td>Country</td>
        <td>${country}</td>
      </tr>
    </table>
    <footer>
    <br>
    This is an automated email. Please do not reply.
    </footer>
  </div>
</body>
</html>
`;

  // Send email
  try {
    await sendGmail(
      email,
      "Thank you For Donation",
      "Thank you For Donation",
      template
    );
    console.log("Email sent successfully.");
  } catch (error) {
    console.error("Error sending email:", error);
    // Handle email sending error if needed
  }

  // Send response with alert message
  const alert = `
    <script>
      alert("Thank you, ${name}!");
    </script>
  `;
  res.send(alert);
});
